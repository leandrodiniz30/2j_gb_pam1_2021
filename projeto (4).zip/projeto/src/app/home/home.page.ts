import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  imagens = [
    'principal.jpg',
    'crianca.jpg',
    'jovem.jpg',
    'adulto.jpg',
    'idoso.jpg'
  ];
  imagem = this.imagens[0];
    idade=null;
  
  constructor() {}

  verificar(): void{
    if(this.idade>0 && this.idade<=10){
      this.imagem=this.imagens[1]
    }else if(this.idade>11 && this.idade<=25)
      this.imagem=this.imagens[2]}
      else if(this.idade>26 && this.idade<=59)
      this.imagem=this.imagens[3]    
    
    }
    limpar(): void{

    }
  }

  


