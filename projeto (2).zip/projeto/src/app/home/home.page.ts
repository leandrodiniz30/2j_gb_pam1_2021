import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  imagens = [
    'principal.jpg',
    'crianca.jpg',
    'jovem.jpg',
    'adulto.jpg',
    'idoso.jpg'
  ];
  imagem = this.imagens[0];
  
  
  constructor() {}

  verificar(): void{
    

    
    }
    limpar(): void{

    }
  }

  


